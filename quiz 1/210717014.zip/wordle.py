import sys # get the word of day
WoD = str(sys.argv[1]).upper()  # 1. index because of the concept of sys.argv is i want to take the value of the entered from command line

try: # check the length of WoD value if it is 5 or else " if that part is not satisfied, The program will be finished"
    if len(WoD) !=5:
        raise Exception("the word of day has to be 5 letter not less or more")
except Exception:
    print("The word of day has to be 5 letter not less or more. Try again!")
    sys.exit()

counter = 1 # declaring a counter value for giving 6 times to try
dictOfIndexes = {0:None,1:None,2:None,3:None,4:None} # in here, we are using dict system to handling if WoD and typed value is matching by indexes
indexNumbersOfWoD = 0 # it means that we can check the indexes are equal and values of indexes. We use dict we have to use index counter.
indexNumbersOfGetValue = 0 # basicly same mechanic but for getValue

def thereIsMatch(color): # that function uses for dyeing the indexes with colors green and orange
    if color == "Green":
        dictOfIndexes[indexNumbersOfWoD] = color
    if color == "Orange":
        dictOfIndexes[indexNumbersOfGetValue] = color
    
def printSection(dictOfIndexes): # printing format
    print(f"Try{counter} ({getValue}):")
    for key,value in dictOfIndexes.items(): # basicly printing the values depending the keys 
        if value == None:
            print(f"{key+1}. letter does not exist.")
        if value == "Orange":
            print(f"{key+1}. letter exists but located in wrong position.")
        if value == "Green":
            print(f"{key+1}. letter exists and located in right position.")


while counter < 7: # it gives 6 chance to try     
    getValue = str(input("Enter the world of day:")).upper()
    
    if len(getValue) != 5:
        print(f"Try{counter} ({getValue}): The word that has been entered should include 5 character, try again!")
        counter += 1
        continue # there is a wrong therefore i am skipping all but i add counter 1 because we skipped
    for index1 in WoD: # checking items in the world of day for matching with typed text
        for index2 in getValue: # basicly checking them if there is a match
            if index1 == index2:
                if WoD.index(index1) == getValue.index(index2):
                    thereIsMatch("Green")
                else:
                    thereIsMatch("Orange")
            indexNumbersOfGetValue += 1 # we are increasing the value of index getValue by 1
        indexNumbersOfGetValue = 0 # we checked the first index1 in WoD with every index2 in getValue. Therefore we are declare it 0. 
        indexNumbersOfWoD += 1 # we are increasing the value of index getValue by 1
    indexNumbersOfWoD = 0 # we checked the first index1 in WoD with every index2 in getValue. Therefore we are declare it 0. 
    printSection(dictOfIndexes)
    if {0:"Green",1:"Green",2:"Green",3:"Green",4:"Green"} == dictOfIndexes: # if they all green that means words are right 
        break
    dictOfIndexes = {0:None,1:None,2:None,3:None,4:None} # if we didnt make that default, then we will get the values of the last word. Then we make
    counter += 1 # we are increasing this value for checking the try     times
    
if counter == 7:
    print("You are failed!")
else:
    print(f"Try{counter} ({WoD}): Congratulations! You guess right in {counter}th shot!")
