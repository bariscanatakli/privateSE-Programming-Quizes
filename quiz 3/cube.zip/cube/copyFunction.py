from states import onyuz, sagyuz, arkayuz, solyuz, altyuz, ustyuz

def copyFaces():
    onyuzCopy, sagyuzCopy, arkayuzCopy, solyuzCopy, altyuzCopy, ustyuzCopy = onyuz.copy(), sagyuz.copy(), arkayuz.copy(), solyuz.copy(), altyuz.copy(), ustyuz.copy()
    return onyuzCopy, sagyuzCopy, arkayuzCopy, solyuzCopy, altyuzCopy, ustyuzCopy