onyuz = {}
arkayuz = {}
ustyuz = {}
altyuz = {}
sagyuz = {}
solyuz = {}


lineStart = int()
lineEnd = int() 



for square in range(1,10):
    onyuz.update({square:"green"})
    arkayuz.update({square:"blue"})
    ustyuz.update({square:"white"})
    altyuz.update({square:"yellow"})
    sagyuz.update({square:"red"})
    solyuz.update({square:"magenta"})

