commands = open("commandsP2.txt").read().split(",") # reading
cities = [city.removesuffix("\n") for city in open("city.txt", "r")] # reading
dictCities = dict()
for relation in cities: # declare relation values as the lines of cities
    listCities = relation.split(":") 
    dictCities.update({listCities[0]: listCities[1]})

for command in commands:
    if command != ",":
        try:
            for cityFirst in str(dictCities[command]).split(" "): # we are getting the cities of the first values
                try:
                    if cityFirst not in str(dictCities[command]).split(" "): #if not in there add to dictCities
                        dictCities[command] += f"{cityFirst}"
                    for citySecond in str(dictCities[cityFirst]).split(" "): #we are getting the cities of the second values
                        try:
                            if citySecond not in str(dictCities[command]).split(" "): #if not in there add to dictCities
                                dictCities[command] += f" {citySecond}"
                            for cityThird in str(dictCities[citySecond]).split(" "): # we are getting the cities of the thirdValues
                                try:
                                    if cityThird not in str(dictCities[command]).split(" "): # if not in there add to dictCities 
                                        dictCities[command] += f" {cityThird}"
                                except KeyError:
                                    pass
                        except KeyError:
                            pass
                except KeyError:
                    pass
        except KeyError:
            pass
for command in commands:# print part
    if command != ",": 
        try:
            listCities = str(dictCities[command]).split(" ")
            for city in listCities: 
                if city == " ":
                    listCities.remove(" ")
            
            print(f"'{command}': {listCities}")
        except KeyError:
            print(f"City '{command}' has no reachable neighbour")

