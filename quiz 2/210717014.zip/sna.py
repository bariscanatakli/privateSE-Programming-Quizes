try:
    open('nicknames.txt', 'x') # for creating
except FileExistsError: # if file exists
    nicknames = [nickname.removesuffix("\n") for nickname in open("nicknames.txt")] # create a list object with every data in the file nicknames.txt
commands = [command.removesuffix("\n") for command in open("commandsP1.txt")] # create a list object with every data in the file commandsP1.txt

def writeFunction(command):
    nicknames = open('nicknames.txt',"a") # open as 'a' mode
    nicknames.write(f"{firstParameter}\n") # write
    relations = open('sn.txt',"a") # open as 'a' mode
    relations.write(f"{firstParameter}:\n") # write
    print(command,f"=> User {firstParameter} added successfully.") #printing 

def removeUser(linesOfNicknames):
    nicknamesUsers = open('nicknames.txt',"w") #open as 'w' mode
    lineCountNickname = 0 # we use that part for understanding which line we are at.
    for nickname in linesOfNicknames: # every nickname in the file.
        if nickname.removesuffix("\n") == firstParameter: #if nickname is equal the given parameter
            linesOfNicknames.remove(linesOfNicknames[lineCountNickname])  #removing 
            nicknamesUsers.writelines(linesOfNicknames) # write the list that we have updated
        lineCountNickname+=1 #we are increasing the count of line
def removeRelation(linesOfRelations):
    relations = open('sn.txt',"w") #open as 'w' mode
    lineCountRelation = 0 # we use that part for understanding which line we are at.
    for relation in linesOfRelations: # every relation in the file
        if firstParameter in relation: # if first parameter in the relation
            linesOfRelations[linesOfRelations.index(relation)] = relation.replace(firstParameter,"") # replacing the parameter as ""
        if relation[0] == firstParameter: # first index of each relation in the file. Checking the equality with the first parameter
            linesOfRelations.remove(linesOfRelations[lineCountRelation]) # removing
            relations.writelines(linesOfRelations) # write the list that we have updated
        lineCountRelation +=1 #we are increasing the count of line

def deleteFunction(command):
    relations = open('sn.txt',"r") # open as 'r' mode
    nicknamesUsers = open('nicknames.txt',"r") # open as 'r' mode
    linesOfRelations = relations.readlines() # readlines 
    linesOfNicknames = nicknamesUsers.readlines() # readlines
    removeUser(linesOfNicknames) # function to remove users
    removeRelation(linesOfRelations) # function to remove relatinos 
    # they both are getting used at the same time bcs when we remove any user we want to delete their relations as well.
    print(command,f"=> User {firstParameter} and its all relations have been removed successfully.") # printing
    
def updateRelationFunction(dictRelations):
    relations = open('sn.txt',"w") # open as 'w' mode
    for key,value in dictRelations.items(): # key values in the dict relations
        relations.write(f"{key}:{value}\n") # we are writing for updating
    relations.close() # close

def addRelationFunction(command):
    dictRelations = createRelationDict() #this function means we are creating a dict object
    for key,value in dictRelations.items(): #key values in the dict relations we are iterating
        if key == firstParameter and secondParameter not in value: #if first parameter is equal at the key that we iterated and second parameter is not in the value of dict Relations (that means relations = value)
            dictRelations.update({key:value+" "+secondParameter}) #update means we are adding a new relation
        if key == secondParameter and firstParameter not in value: # we are doing some methods as we change first parameter to second 
            dictRelations.update({key:value+" "+firstParameter}) #update means we are adding a new relation
    updateRelationFunction(dictRelations) # we are updating the file called sn.txt

    print(command,F"=> A relation between {firstParameter} and {secondParameter} been added successfully.")

def createRelationDict():
    relations = [relation.removesuffix("\n") for relation in open("sn.txt","r")] # open as r and create a list called relations
    
    dictRelations = dict()
    for relation in relations:
        listRelation = relation.split(":")
        dictRelations.update({listRelation[0]:listRelation[1]}) # this allows to create a new relation 

    return dictRelations

def removeRelationFunction(command):
    dictRelations = createRelationDict()
    
    for key,value in dictRelations.items():
        if key == firstParameter and secondParameter in value:
            dictRelations.update({key:value.replace(secondParameter,"")}) #replace the second parameter with nothing so we delete basicly

        if key == secondParameter and firstParameter in value:
            dictRelations.update({key:value.replace(firstParameter,"")}) #replace the firsts parameter with nothing so we delete basicly

    updateRelationFunction(dictRelations) # we are updating the file called sn.txt

    print(command,F"=> A relation between {firstParameter} and {secondParameter} has been removed successfully.")

def missingArgument(command):
    print(command,"=> Missing argument.") #print argument

def openFunction(): # that part of the function is opening the files every time that func is called.
    global commands, nicknames
    commands = [command.removesuffix("\n") for command in open("commandsP1.txt")]
    nicknames = [nickname.removesuffix("\n") for nickname in open("nicknames.txt")]
    nicknames = dict(zip(nicknames,range(1,1+len(nicknames))))

def addUserCommand(command):
    if firstCommand == "AU": # IF XY EXISTS #
        try:
            if firstParameter and len(listCommands) < 3: # IF XY Z EXISTS
                openFunction() # openning
                if firstParameter in nicknames: # IF XY Z EQUAL THE GIVEN COMMAND
                    print(command,"=> This user already exists!")
                else:
                    writeFunction(command)
            else:
                missingArgument(command)
        except NameError:
            missingArgument(command)
def removeUserCommand(command):
    if firstCommand == "RU": # IF XY EXISTS
        if firstParameter and len(listCommands) < 3: #IF XY Z EXISTS
            openFunction()
            if firstParameter in nicknames: # IF XY Z EQUAL THE GIVEN COMMAND
                deleteFunction(command)
            else:
                print(command,F"=> There is no user named {firstParameter}")
        else:
            missingArgument(command)

def addNewRelationCommand(command):
    if firstCommand == "AR": # IF XY EXISTS
        if len(listCommands) == 3: #IF XY Z EXISTS
            openFunction()
            dictRelations = createRelationDict()
            for relation1 in dictRelations: # we check the first relation in dictRelations
                    for relation2 in dictRelations: #we check the second relation in at the same list
                        if relation1 == firstParameter and relation2 == secondParameter: # if they are same
                            if secondParameter in dictRelations[relation1] and firstParameter in dictRelations[relation2]: # and if they are in the lists
                                return print(command, f"=> A relation between {firstParameter} and {secondParameter} already exists!") #there is a match so they are exist
            if firstParameter in nicknames and secondParameter in nicknames: # IF XY Z1 Z2 EQUAL THE GIVEN COMMAND
                addRelationFunction(command)
            else:
                print(command,F"=> No user named {firstParameter} or {secondParameter} found! ")
        else:
            missingArgument(command)
def removeExistingRelationCommand(command):
    if firstCommand == "RR": # IF XY EXISTS
        if len(listCommands) == 3: #IF XY Z EXISTS
            openFunction() #openning
            if firstParameter in nicknames and secondParameter in nicknames: # IF XY Z1 Z2 EQUAL THE GIVEN COMMAND
                removeRelationFunction(command) #this function removing the relations 
            else:
                print(command,F"=> No user named {firstParameter} or {secondParameter} found! ")
        else:
            missingArgument(command)

def rankUsersFunction(dictRelations):
    print(command, "=>")
    for user,rank in dictRelations.items(): #this part of function allows us the get the value of count 
        count = len(set(rank.split(" "))) -1  
        print(f"User {user} has {count} friends")

    relationsFriendsRank = list()
    for key,values in dictRelations.items(): # basicly that part does the same processes again
        count = len(set(values.split(" "))) -1  
        relationsFriendsRank.append((count,key)) # add to list called relationsFriendsRank
    relationsFriendsRank.sort(reverse=True) #we are sorting to show the sorted list
    counter = 0
    for user in relationsFriendsRank: 
        if counter < int(command[3:5]):
            print(f"{counter+1}. '{user[1]}':{user[0]}")
        counter += 1

def rankUsersCommand(command):
    if firstCommand == "PA" and command[3:]: # IF XY EXISTS
        if type(int(command[3:5])) == int:
            nicknames = open("nicknames.txt","r")
            if len(list(nicknames)) < int(command[3:5]): # if the given value is greater print it is greater than X
                print(command,"=> Invalid input since n is greater than X")
            else:
                dictRelations = createRelationDict()
                rankUsersFunction(dictRelations)
    else:
        missingArgument(command)        
                
def suggestFriendShipFunction(dictRelation):
    allFriendsList = list()
    for relation in dictRelation:
        listRelationFirst = list(set(dictRelation[relation].split(" "))) # we are removing the " " part from the values (actually relations)
        listRelationFirst.pop(0) # the first line is " " so i pop it
        if firstParameter == relation: #if the given parameter first is equaled with the relation that we yield 
            for relationFirst in listRelationFirst: # we are searching relationFirst value in the list that we created called listRelationFirst which is the relations of the firstParameter
                listRelationSecond = list(set(dictRelation[relationFirst].split(" "))) # we are doing the same steps for secondList
                listRelationSecond.pop(0)
                for relationSecond in listRelationSecond: # and we are searching the other relation for secondParameter 
                    allFriendsList.append(relationSecond)
    allFriendsSet = set(allFriendsList) # we get the values without duplicating
    suggestionFriendsList = list()
    for friend in allFriendsSet:
        if int(secondParameter) <= allFriendsList.count(friend): # we check the command if given number is small or equal the count of friend
            if friend != firstParameter:
                suggestionFriendsList.append(friend)

    print(command,"=>")
    if len(suggestionFriendsList):
        print(f"Suggestion List for '{firstParameter}' (when MD is {secondParameter}):")
    if int(secondParameter) >= suggestionFriendsList.count(friend): # if it is greater than the command number execute
        for friend in suggestionFriendsList:
            print(f"'{firstParameter}' has {allFriendsList.count(friend)} mutual friends with {friend}")
    else:
        print(f"User {firstParameter} has friends less than {secondParameter}")
def suggestFriendshipCommand(command):
    if firstCommand == "SA": # IF XY EXISTS
        if len(listCommands) == 3:
            if type(int(secondParameter)) == int:
                dictRelation = createRelationDict() # get the dict of Relation
                
                suggestFriendShipFunction(dictRelation) # function 
            else:
                missingArgument(command)
        else:
            missingArgument(command)
for command in commands: # the first thing is working when program starts
    if command:
        listCommands = command.split(" ") # making list of the given command to get parameters
        try:
            firstCommand = listCommands[0] # first command like AU
            firstParameter = listCommands[1] # first parameter like BARIS
            secondParameter = listCommands[2] # second parameter like BARIS or 5
        except:
            pass
        if firstCommand == "AU":
            addUserCommand(command)
        elif firstCommand == "RU":
            removeUserCommand(command)
        elif firstCommand == "AR":
            addNewRelationCommand(command)
        elif firstCommand == "RR":
            removeExistingRelationCommand(command)
        elif firstCommand == "PA":
            rankUsersCommand(command)
        elif firstCommand == "SA":
            suggestFriendshipCommand(command)

